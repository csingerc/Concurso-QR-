// ============================================================
// BASE DE DATOS RUT → NOMBRE
// Reemplazar con el archivo real que proveerá Camilo
// Formato: { "rut-normalizado": "Nombre Apellido" }
// RUT normalizado = sin puntos, con guión, todo lowercase
// ============================================================

const RUT_DB = {
  "12345678-9": "Camilo Singer",
  "11111111-1": "María González",
  "22222222-2": "Jean Pierre Dupont",
  "33333333-3": "Rosa Mamani",
  "44444444-4": "Carlos Fuentes",
  "55555555-5": "Ana Martínez",
  "66666666-6": "Pedro Rojas",
  "77777777-7": "Lucía Vargas",
  "88888888-8": "François Bernard",
  "99999999-9": "Isabel Campos",
  // ... el resto se carga desde el CSV real
};

// Función de normalización — misma lógica en cliente y servidor
function normalizarRut(rut) {
  return rut
    .toLowerCase()
    .replace(/\./g, '')     // quita puntos
    .replace(/\s/g, '')     // quita espacios
    .trim();
}

function buscarNombrePorRut(rut) {
  const normalizado = normalizarRut(rut);
  return RUT_DB[normalizado] || null;
}
